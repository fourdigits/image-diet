from image_diet.test_diet import DietTest
from image_diet.test_commands import DietCommandTest
