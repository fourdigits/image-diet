from image_diet import signals
from image_diet.diet import squeeze

VERSION = '0.7'
